import { useCallback } from "react";
import { TextField, InputAdornment, Icon, IconButton } from "@mui/material";
import { useNavigate } from "react-router-dom";
import styles from "./AdminLoginPage3.module.css";

const AdminLoginPage3 = () => {
  const navigate = useNavigate();

  const onNextButtonClick = useCallback(() => {
    navigate("/admin-home-page");
  }, [navigate]);

  const onBackButtonClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className={styles.adminLoginPage3}>
      <img
        className={styles.clarityeyeHideLineIcon}
        alt=""
        src="/clarityeyehideline.svg"
      />
      <img
        className={styles.adminLoginPage3Child}
        alt=""
        src="/group-2245.svg"
      />
      <div className={styles.adminLoginPage3Item} />
      <img className={styles.vectorIcon} alt="" src="/vector.svg" />
      <b className={styles.uploadImage}>Upload Image</b>
      <div className={styles.adminLoginPage3Inner} />
      <div className={styles.lineDiv} />
      <img
        className={styles.rectangleIcon}
        alt=""
        src="/rectangle-1379@2x.png"
      />
      <img className={styles.image14Icon} alt="" src="/image-14@2x.png" />
      <img className={styles.image16Icon} alt="" src="/image-16@2x.png" />
      <img
        className={styles.imageRemovebgPreview1Icon}
        alt=""
        src="/imageremovebgpreview-1@2x.png"
      />
      <b className={styles.edublogger}>EduBlogger</b>
      <img
        className={styles.adminLoginPage3Child1}
        alt=""
        src="/rectangle-1398.svg"
      />
      <img
        className={styles.adminLoginPage3Child2}
        alt=""
        src="/rectangle-13981.svg"
      />
      <img
        className={styles.adminLoginPage3Child3}
        alt=""
        src="/rectangle-13982.svg"
      />
      <img
        className={styles.adminLoginPage3Child4}
        alt=""
        src="/rectangle-13983.svg"
      />
      <div className={styles.entercode}>
        <div className={styles.weSendYouContainer}>
          <span className={styles.weSendYouContainer1}>
            <span
              className={styles.weSendYou}
            >{`We send you an email to your `}</span>
            <b className={styles.dvgalinggmailcom}>{`@dv.galing@gmail.com `}</b>
            <span className={styles.weSendYou}>
              a code. Please provide the verification below
            </span>
          </span>
        </div>
        <b className={styles.hiAdminDave}>Hi Admin Dave!</b>
        <TextField
          className={styles.enterCodeTextbox}
          color="primary"
          label="Enter Code"
          sx={{ width: 343 }}
          variant="filled"
        />
        <button className={styles.nextButton} onClick={onNextButtonClick}>
          <div className={styles.nextButtonChild} />
          <div className={styles.next}>Next</div>
        </button>
        <button className={styles.backButton} onClick={onBackButtonClick}>
          <div className={styles.backWrapper}>
            <div className={styles.back}>Back</div>
          </div>
        </button>
      </div>
    </div>
  );
};

export default AdminLoginPage3;
