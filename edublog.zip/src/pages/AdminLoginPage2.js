import { useCallback } from "react";
import { TextField, InputAdornment, Icon, IconButton } from "@mui/material";
import { useNavigate } from "react-router-dom";
import styles from "./AdminLoginPage2.module.css";

const AdminLoginPage2 = () => {
  const navigate = useNavigate();

  const onSearchButtonContainerClick = useCallback(() => {
    navigate("/admin-login-page-3");
  }, [navigate]);

  return (
    <div className={styles.adminLoginPage2}>
      <img
        className={styles.clarityeyeHideLineIcon}
        alt=""
        src="/clarityeyehideline.svg"
      />
      <img
        className={styles.adminLoginPage2Child}
        alt=""
        src="/group-2245.svg"
      />
      <div className={styles.adminLoginPage2Item} />
      <img
        className={styles.iconAlternateCloudUpload}
        alt=""
        src="/-icon-alternate-cloud-upload.svg"
      />
      <b className={styles.uploadImage}>Upload Image</b>
      <div className={styles.adminLoginPage2Inner} />
      <div className={styles.lineDiv} />
      <img
        className={styles.rectangleIcon}
        alt=""
        src="/rectangle-1379@2x.png"
      />
      <img className={styles.image14Icon} alt="" src="/image-14@2x.png" />
      <img className={styles.image16Icon} alt="" src="/image-16@2x.png" />
      <img
        className={styles.imageRemovebgPreview1Icon}
        alt=""
        src="/imageremovebgpreview-1@2x.png"
      />
      <b className={styles.edublogger}>EduBlogger</b>
      <img
        className={styles.adminLoginPage2Child1}
        alt=""
        src="/rectangle-1398.svg"
      />
      <img
        className={styles.adminLoginPage2Child2}
        alt=""
        src="/rectangle-13981.svg"
      />
      <img
        className={styles.adminLoginPage2Child3}
        alt=""
        src="/rectangle-13982.svg"
      />
      <img
        className={styles.adminLoginPage2Child4}
        alt=""
        src="/rectangle-13983.svg"
      />
      <div className={styles.findYourAccount}>Find your account</div>
      <div className={styles.fileds}>
        <div
          className={styles.searchButton}
          onClick={onSearchButtonContainerClick}
        >
          <button className={styles.button}>
            <div className={styles.rectangleParent}>
              <div className={styles.groupChild} />
              <div className={styles.search}>Search</div>
            </div>
          </button>
        </div>
        <div className={styles.enterEmail}>
          <TextField
            className={styles.enterEmailChild}
            color="primary"
            label="username@gmail.com"
            fullWidth={true}
            variant="filled"
          />
          <div className={styles.enterYourEmailContainer}>
            <span className={styles.enterYourEmailContainer1}>
              <span>{`Enter your Email `}</span>
              <span className={styles.span}>*</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminLoginPage2;
