import { useCallback } from "react";
import { TextField, InputAdornment, Icon, IconButton } from "@mui/material";
import { useNavigate } from "react-router-dom";
import styles from "./AdminLoginPage1.module.css";

const AdminLoginPage1 = () => {
  const navigate = useNavigate();

  const onForgotPasswordClick = useCallback(() => {
    navigate("/admin-login-page-2");
  }, [navigate]);

  return (
    <div className={styles.adminLoginPage1}>
      <img className={styles.sideDesignIcon} alt="" src="/side-design.svg" />
      <button className={styles.forgotPassword} onClick={onForgotPasswordClick}>
        Forgot Password?
      </button>
      <div className={styles.fields}>
        <button className={styles.loginButton}>
          <div className={styles.loginButton1}>
            <div className={styles.loginButtonChild} />
            <div className={styles.login}>Login</div>
          </div>
        </button>
        <div className={styles.password}>
          <TextField
            className={styles.passwordTextbox}
            color="primary"
            label="Password"
            fullWidth={true}
            variant="filled"
          />
          <div className={styles.password1}>
            <span className={styles.passwordTxtContainer}>
              <span>
                <span>Password</span>
                <span className={styles.span}>{` `}</span>
              </span>
              <span className={styles.span}>
                <span>*</span>
              </span>
            </span>
          </div>
        </div>
        <div className={styles.position}>
          <TextField
            className={styles.positionTextbox}
            color="primary"
            label="e.g. System Analyst"
            fullWidth={true}
            variant="filled"
          />
          <div className={styles.position1}>
            <span className={styles.passwordTxtContainer}>
              <span>{`Position `}</span>
              <span className={styles.span2}>*</span>
            </span>
          </div>
        </div>
        <div className={styles.email}>
          <TextField
            className={styles.positionTextbox}
            color="primary"
            label="username@gmail.com"
            fullWidth={true}
            variant="filled"
          />
          <div className={styles.eMail}>
            <span className={styles.passwordTxtContainer}>
              <span>{`E-mail `}</span>
              <span className={styles.span2}>*</span>
            </span>
          </div>
        </div>
        <div className={styles.fullname}>
          <TextField
            className={styles.nameTextbox}
            color="primary"
            label="Name"
            fullWidth={true}
            variant="filled"
          />
          <div className={styles.fullNameContainer}>
            <span className={styles.passwordTxtContainer}>
              <span>{`Full Name `}</span>
              <span className={styles.span2}>*</span>
            </span>
          </div>
        </div>
      </div>
      <div className={styles.logo}>
        <img
          className={styles.imageRemovebgPreview1Icon}
          alt=""
          src="/imageremovebgpreview-1@2x.png"
        />
        <b className={styles.edublogger}>EduBlogger</b>
      </div>
    </div>
  );
};

export default AdminLoginPage1;
