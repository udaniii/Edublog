import styles from "./AdminMenuButton.module.css";

const AdminMenuButton = () => {
  return (
    <div className={styles.adminMenuButton}>
      <img
        className={styles.adminMenuButtonChild}
        alt=""
        src="/-icon-alternate-cloud-upload.svg"
      />
      <img
        className={styles.imageRemovebgPreview42}
        alt=""
        src="/imageremovebgpreview-4-2@2x.png"
      />
      <img
        className={styles.adminMenuButtonItem}
        alt=""
        src="/rectangle-1396.svg"
      />
      <div className={styles.bell1} />
      <button className={styles.more1Wrapper}>
        <img className={styles.more1Icon} alt="" src="/more-1@2x.png" />
      </button>
      <img
        className={styles.adminMenuButtonInner}
        alt=""
        src="/rectangle-1394.svg"
      />
      <img className={styles.rectangleIcon} alt="" src="/rectangle-2.svg" />
      <img className={styles.line1Stroke} alt="" src="/line-1-stroke.svg" />
      <div className={styles.dataAnalyst}>Data Analyst</div>
      <b className={styles.daveRyanGaling}>Dave Ryan Galing</b>
      <button className={styles.dashboard}>
        <img
          className={styles.speedometer1Icon}
          alt=""
          src="/speedometer-1@2x.png"
        />
        <b className={styles.dashboard1}>Dashboard</b>
        <img
          className={styles.plainTriangle1Icon}
          alt=""
          src="/plaintriangle-1@2x.png"
        />
      </button>
      <button className={styles.logs}>
        <img className={styles.security1Icon} alt="" src="/security-1@2x.png" />
        <b className={styles.dashboard2}>Logs</b>
        <img
          className={styles.plainTriangle1Icon1}
          alt=""
          src="/plaintriangle-11@2x.png"
        />
      </button>
      <button className={styles.reports}>
        <img className={styles.report1Icon} alt="" src="/report-1@2x.png" />
        <b className={styles.reports1}>Reports</b>
      </button>
      <button className={styles.userManagement}>
        <img
          className={styles.management1Icon}
          alt=""
          src="/management-1@2x.png"
        />
        <b className={styles.userManagement1}>User Management</b>
      </button>
      <button className={styles.analytics}>
        <button className={styles.analytics1}>
          <img
            className={styles.analytics1Icon}
            alt=""
            src="/analytics-1@2x.png"
          />
        </button>
        <b className={styles.analytic}>Analytic</b>
      </button>
      <button className={styles.logout}>
        <img className={styles.vectorIcon} alt="" src="/vector1.svg" />
      </button>
      <img className={styles.image60Icon} alt="" src="/image-601@2x.png" />
      <img className={styles.image61Icon} alt="" src="/image-60@2x.png" />
      <img
        className={styles.imageRemovebgPreview44}
        alt=""
        src="/imageremovebgpreview-4-3@2x.png"
      />
      <img
        className={styles.adminMenuButtonChild1}
        alt=""
        src="/rectangle-1381.svg"
      />
      <b className={styles.hiWelcomeAdmin}>Hi! Welcome, Admin Dave!</b>
    </div>
  );
};

export default AdminMenuButton;
