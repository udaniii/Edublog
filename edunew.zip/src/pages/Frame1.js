import styles from "./Frame1.module.css";

const Frame1 = () => {
  return (
    <div className={styles.div}>
      <img className={styles.child} alt="" src="/home.svg" />
      <img
        className={styles.imageRemovebgPreview42}
        alt=""
        src="/imageremovebgpreview-4-2@2x.png"
      />
      <img className={styles.item} alt="" src="/rectangle-1396.svg" />
      <img className={styles.bell1Icon} alt="" src="/bell-1@2x.png" />
      <img className={styles.three2Icon} alt="" src="/three-2@2x.png" />
      <button className={styles.more1Wrapper}>
        <img className={styles.more1Icon} alt="" src="/more-1@2x.png" />
      </button>
      <div className={styles.sideBar}>
        <img className={styles.sideBarChild} alt="" src="/rectangle-1394.svg" />
        <img className={styles.sideBarItem} alt="" src="/rectangle-2.svg" />
        <img className={styles.line1Stroke} alt="" src="/line-1-stroke.svg" />
        <div className={styles.dataAnalyst}>Data Analyst</div>
        <b className={styles.daveRyanGaling}>Dave Ryan Galing</b>
        <button className={styles.dashboard}>
          <img
            className={styles.speedometer1Icon}
            alt=""
            src="/speedometer-1@2x.png"
          />
          <img
            className={styles.plainTriangle1Icon}
            alt=""
            src="/plaintriangle-1@2x.png"
          />
          <b className={styles.reports}>Dashboard</b>
        </button>
        <button className={styles.report}>
          <img className={styles.report1Icon} alt="" src="/report-1@2x.png" />
          <img className={styles.image60Icon} alt="" src="/image-601@2x.png" />
          <b className={styles.reports}>Reports</b>
        </button>
        <button className={styles.userManagement}>
          <img
            className={styles.management1Icon}
            alt=""
            src="/management-1@2x.png"
          />
          <b className={styles.analytic}>User Management</b>
        </button>
        <button className={styles.analytics}>
          <img
            className={styles.analytics1Icon}
            alt=""
            src="/analytics-1@2x.png"
          />
          <b className={styles.analytic}>Analytic</b>
        </button>
        <button className={styles.vectorWrapper}>
          <img className={styles.vectorIcon} alt="" src="/vector.svg" />
        </button>
      </div>
      <img className={styles.image61Icon} alt="" src="/image-60@2x.png" />
      <img
        className={styles.imageRemovebgPreview44}
        alt=""
        src="/imageremovebgpreview-4-3@2x.png"
      />
      <img className={styles.inner} alt="" src="/rectangle-1381.svg" />
      <b className={styles.hiWelcomeAdmin}>Hi! Welcome, Admin Dave!</b>
    </div>
  );
};

export default Frame1;
