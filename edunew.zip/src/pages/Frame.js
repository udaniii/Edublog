import { useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./Frame.module.css";

const Frame = () => {
  const navigate = useNavigate();

  const onProductClick = useCallback(() => {
    // Please sync "Dashboard/Home" to the project
  }, []);

  const onGroupContainerClick = useCallback(() => {
    // Please sync "Profile" to the project
  }, []);

  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add(styles.animate);
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  const onFrameButtonClick = useCallback(() => {
    navigate("/2");
  }, [navigate]);

  return (
    <div className={styles.div}>
      <img className={styles.child} alt="" src="/rectangle-1395.svg" />
      <img className={styles.image60Icon} alt="" src="/image-60@2x.png" />
      <div className={styles.item} />
      <img className={styles.homeIcon} alt="" src="/home.svg" />
      <img
        className={styles.productIcon}
        alt=""
        src="/product.svg"
        onClick={onProductClick}
      />
      <img className={styles.customerIcon} alt="" src="/customer.svg" />
      <img className={styles.image2Icon} alt="" src="/image-2@2x.png" />
      <div className={styles.calendarParent} onClick={onGroupContainerClick}>
        <div className={styles.calendar}>Calendar</div>
        <img className={styles.customerIcon1} alt="" src="/customer1.svg" />
        <img className={styles.iconCalendar} alt="" src="/-icon-calendar.svg" />
      </div>
      <img
        className={styles.imageRemovebgPreview42}
        alt=""
        src="/imageremovebgpreview-4-2@2x.png"
      />
      <div className={styles.bell1Wrapper}>
        <img className={styles.bell1Icon} alt="" src="/bell-1@2x.png" />
      </div>
      <img className={styles.three2Icon} alt="" src="/three-2@2x.png" />
      <button
        className={styles.more1Wrapper}
        onClick={onFrameButtonClick}
        data-animate-on-scroll
      >
        <img className={styles.more1Icon} alt="" src="/more-1@2x.png" />
      </button>
      <img className={styles.inner} alt="" src="/home.svg" />
      <img
        className={styles.imageRemovebgPreview43}
        alt=""
        src="/imageremovebgpreview-4-3@2x.png"
      />
      <img className={styles.rectangleIcon} alt="" src="/rectangle-1380.svg" />
      <b className={styles.hiWelcomeAdmin}>Hi! Welcome, Admin Dave!</b>
    </div>
  );
};

export default Frame;
