import styles from "./Frame.module.css";

const Frame = () => {
  return (
    <div className={styles.div}>
      <div className={styles.frame}>
        <div className={styles.frameChild} />
      </div>
      <img
        className={styles.evaarrowIosDownwardFillIcon}
        alt=""
        src="/evaarrowiosdownwardfill.svg"
      />
      <img
        className={styles.helpAndLogOut}
        alt=""
        src="/help-and-log-out.svg"
      />
      <img className={styles.child} alt="" src="/evaarrowiosdownwardfill.svg" />
      <div className={styles.calendarParent}>
        <div className={styles.calendar}>Calendar</div>
        <img
          className={styles.evaarrowIosDownwardFillIcon1}
          alt=""
          src="/evaarrowiosdownwardfill1.svg"
        />
        <img className={styles.vectorIcon} alt="" src="/vector.svg" />
      </div>
      <img
        className={styles.imageRemovebgPreview42}
        alt=""
        src="/imageremovebgpreview-4-2@2x.png"
      />
      <img className={styles.item} alt="" src="/rectangle-1394.svg" />
      <img className={styles.inner} alt="" src="/rectangle-1400.svg" />
      <button className={styles.logOut}>
        <img
          className={styles.helpAndLogOut1}
          alt=""
          src="/help-and-log-out.svg"
        />
      </button>
      <img className={styles.item} alt="" src="/rectangle-1394.svg" />
      <div className={styles.dataAnalyst}>Data Analyst</div>
      <b className={styles.daveRyanGaling}>Dave Ryan Galing</b>
      <div className={styles.dataAnalyst1}>Data Analyst</div>
      <button className={styles.analytic}>
        <img
          className={styles.analytics1Icon}
          alt=""
          src="/analytics-1@2x.png"
        />
        <b className={styles.analytic1}>Analytic</b>
      </button>
      <button className={styles.userManagement}>
        <img
          className={styles.management1Icon}
          alt=""
          src="/management-1@2x.png"
        />
        <b className={styles.analytic1}>User Management</b>
      </button>
      <button className={styles.reports}>
        <img className={styles.report1Icon} alt="" src="/report-1@2x.png" />
        <b className={styles.analytic1}>Reports</b>
      </button>
      <button className={styles.dashboard} />
      <img className={styles.child1} alt="" src="/rectangle-1396.svg" />
      <img className={styles.bell1Icon} alt="" src="/bell-1@2x.png" />
      <img className={styles.three2Icon} alt="" src="/three-2@2x.png" />
      <button className={styles.bars}>
        <img className={styles.barIcon} alt="" src="/3-bar@2x.png" />
      </button>
      <img className={styles.profileIcon} alt="" src="/profile@2x.png" />
      <img
        className={styles.child2}
        alt=""
        src="/evaarrowiosdownwardfill.svg"
      />
      <img
        className={styles.plainTriangle1Icon}
        alt=""
        src="/plaintriangle-1@2x.png"
      />
      <img
        className={styles.speedometer1Icon}
        alt=""
        src="/speedometer-1@2x.png"
      />
      <b className={styles.daveRyanGaling1}>Dashboard</b>
      <img className={styles.image61Icon} alt="" src="/image-61@2x.png" />
      <img className={styles.child3} alt="" src="/rectangle-1404.svg" />
      <img className={styles.searchIcon} alt="" src="/search.svg" />
      <b className={styles.name}>1</b>
      <b className={styles.name1}>1</b>
      <b className={styles.name2}>1</b>
      <b className={styles.name3}>1</b>
      <b className={styles.name4}>43</b>
      <b className={styles.name5}>43</b>
      <b className={styles.name6}>43</b>
      <b className={styles.name7}>43</b>
      <b
        className={styles.name8}
      >{`Gikapoy nako sakong kinabuhi gusto nalang ko mahimong kambing kay kapoy jud `}</b>
      <b
        className={styles.name9}
      >{`Gikapoy nako sakong kinabuhi gusto nalang ko mahimong kambing kay kapoy jud `}</b>
      <b
        className={styles.name10}
      >{`Gikapoy nako sakong kinabuhi gusto nalang ko mahimong kambing kay kapoy jud `}</b>
      <b
        className={styles.name11}
      >{`Gikapoy nako sakong kinabuhi gusto nalang ko mahimong kambing kay kapoy jud `}</b>
      <b className={styles.title}>Title</b>
      <b className={styles.title1}>Category</b>
      <b className={styles.title2}>Content</b>
      <b className={styles.title3}>Likes</b>
      <b className={styles.title4}>Comments</b>
      <b className={styles.title5}>Action</b>
      <b className={styles.title6}>Date Posted</b>
      <img className={styles.child4} alt="" src="/rectangle-1406.svg" />
      <button className={styles.showProfile5}>
        <img className={styles.vectorIcon1} alt="" src="/vector1.svg" />
      </button>
      <button className={styles.showProfile4}>
        <img className={styles.vectorIcon1} alt="" src="/vector2.svg" />
      </button>
      <button className={styles.showProfile3}>
        <img className={styles.vectorIcon1} alt="" src="/vector2.svg" />
      </button>
      <button className={styles.showProfile2}>
        <img className={styles.vectorIcon1} alt="" src="/vector3.svg" />
      </button>
      <button className={styles.showProfile1}>
        <img className={styles.vectorIcon1} alt="" src="/vector3.svg" />
      </button>
      <img className={styles.lineIcon} alt="" src="/line-20.svg" />
      <img className={styles.child5} alt="" src="/rectangle-1405.svg" />
      <div className={styles.shekainahgrace123}>@shekainahgrace123</div>
      <div className={styles.shekainahgrace1231}>@lizeldacup567</div>
      <div className={styles.shekainahgrace1232}>@yudanecalo8910</div>
      <div className={styles.shekainahgrace1233}>@jullianetampus112213</div>
      <div className={styles.shekainahgrace1234}>@unknownuser890</div>
      <img className={styles.child6} alt="" src="/rectangle-1406.svg" />
      <b className={styles.follow7Weeks}>follow 4 days ago</b>
      <b className={styles.follow7Weeks1}>follow 1 month ago</b>
      <b className={styles.follow7Weeks2}>follow 7 weeks ago</b>
      <b className={styles.follow7Weeks3}>follow 3 weeks ago</b>
      <div className={styles.shekainahgrace123followings}>
        @shekainahgrace123
      </div>
      <div className={styles.shekainahgrace123followings1}>@analisa</div>
      <div className={styles.shekainahgrace123followings2}>@labajo6075</div>
      <div className={styles.shekainahgrace123followings3}>@tyuzu123</div>
      <b className={styles.name12}>Name: Dave Ryan Galing</b>
      <b className={styles.name13}>Email: daveryan.galing@carsu.edu.ph</b>
      <b className={styles.name14}>Date Started: November 11, 2023</b>
      <b className={styles.name15}>Username: anonymous1234</b>
      <div className={styles.name16}>
        <b>Activeness</b>
        <span>{` `}</span>
      </div>
      <b className={styles.name17}>48 Followers</b>
      <b className={styles.name18}>Recently Posts</b>
      <b className={styles.name19}>So stress</b>
      <b className={styles.name20}>So stress</b>
      <b className={styles.name21}>So stress</b>
      <b className={styles.name22}>So stress</b>
      <b className={styles.name23}>11-14-2023</b>
      <b className={styles.name24}>11-14-2023</b>
      <b className={styles.name25}>11-14-2023</b>
      <b className={styles.name26}>11-14-2023</b>
      <b className={styles.name27}>Food Blogs</b>
      <b className={styles.name28}>Food Blogs</b>
      <b className={styles.name29}>Food Blogs</b>
      <b className={styles.name30}>Food Blogs</b>
      <b className={styles.name31}>23 Followings</b>
      <button className={styles.delete1}>
        <div className={styles.delete11}>
          <img
            className={styles.delete1Child}
            alt=""
            src="/rectangle-1409.svg"
          />
          <img
            className={styles.delete1Child}
            alt=""
            src="/rectangle-1409.svg"
          />
          <b className={styles.delete12}>Delete</b>
        </div>
      </button>
      <button className={styles.delete2}>
        <div className={styles.delete11}>
          <img
            className={styles.delete2Child}
            alt=""
            src="/rectangle-1409.svg"
          />
          <img
            className={styles.delete2Child}
            alt=""
            src="/rectangle-1409.svg"
          />
          <b className={styles.name32}>Delete</b>
        </div>
      </button>
      <button className={styles.delete3}>
        <div className={styles.delete11}>
          <img
            className={styles.delete2Child}
            alt=""
            src="/rectangle-1409.svg"
          />
          <img
            className={styles.delete2Child}
            alt=""
            src="/rectangle-1409.svg"
          />
          <b className={styles.delete12}>Delete</b>
        </div>
      </button>
      <button className={styles.delete4}>
        <div className={styles.delete11}>
          <img
            className={styles.delete2Child}
            alt=""
            src="/rectangle-1409.svg"
          />
          <img
            className={styles.delete2Child}
            alt=""
            src="/rectangle-1409.svg"
          />
          <b className={styles.name34}>Delete</b>
        </div>
      </button>
      <button className={styles.deleteSelected}>
        <div className={styles.deleteSelected1}>
          <img
            className={styles.deleteSelectedChild}
            alt=""
            src="/rectangle-1411.svg"
          />
          <img
            className={styles.deleteSelectedChild}
            alt=""
            src="/rectangle-1411.svg"
          />
          <b className={styles.name35}>Delete Selected</b>
        </div>
      </button>
      <button className={styles.selectAll}>
        <div className={styles.deleteSelected1}>
          <img
            className={styles.deleteSelectedChild}
            alt=""
            src="/rectangle-1410.svg"
          />
          <img
            className={styles.deleteSelectedChild}
            alt=""
            src="/rectangle-1410.svg"
          />
          <b className={styles.name36}>Select All</b>
        </div>
      </button>
      <img className={styles.image62Icon} alt="" src="/image-62@2x.png" />
      <b className={styles.dashboardView}>Dashboard / View Details</b>
      <img
        className={styles.imageRemovebgPreview52}
        alt=""
        src="/imageremovebgpreview-5-2@2x.png"
      />
      <button className={styles.checkBox1}>
        <img className={styles.square1Icon} alt="" src="/square-1@2x.png" />
      </button>
      <div className={styles.checkBox2}>
        <img className={styles.square1Icon} alt="" src="/square-1@2x.png" />
      </div>
      <div className={styles.checkBox3}>
        <img className={styles.square1Icon} alt="" src="/square-1@2x.png" />
      </div>
      <div className={styles.checkBox4}>
        <img className={styles.square1Icon} alt="" src="/square-1@2x.png" />
      </div>
      <b className={styles.b}>.</b>
      <b className={styles.b1}>.</b>
      <b className={styles.b2}>.</b>
      <b className={styles.b3}>.</b>
    </div>
  );
};

export default Frame;
